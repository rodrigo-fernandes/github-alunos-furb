package exception.banco;

public class ContaBancaria extends Conta implements OperacaoConta {

	public ContaBancaria(String titular, double saldo) {
		super(titular, saldo);
	}

	@Override
	public void depositar(double valor) {
		try {
			if (valor <= 0) {
				throw new ContaException("O valor de deposito deve ser maior que zero");
			}

			setSaldo(getSaldo() + valor);
			System.out.println("Deposito realizado com sucesso.");

		} catch (ContaException e) {
			System.out.println("Erro ao depositar: " + e.getMessage());
		}

	}

	@Override
	public void sacar(double valor) {

		try {

			if (valor <= 0) {
				throw new ContaException("O valor de saque deve ser maior que zero");
			}

			if (valor > getSaldo()) {
				throw new ContaException("Saldo insuficiente");
			}

			setSaldo(getSaldo() - valor);

			System.out.println("Saque realizado com sucesso.");

		} catch (ContaException e) {
			System.out.println("Erro ao sacar");
		}
	}

	@Override
	public void exibirSaldo() {
		System.out.println("Saldo atualizado: R$ " + getSaldo());

	}

}
